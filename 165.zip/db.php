<?php $gudang = array (
  0 => 
  array (
    'id' => 1,
    'nama' => 'Kipas Angin',
    'harga' => 78999,
  ),
  1 => 
  array (
    'id' => 2,
    'nama' => 'AC Badai',
    'harga' => 1299999,
  ),
  2 => 
  array (
    'id' => 3,
    'nama' => 'Kabel Nyetrum',
    'harga' => 5999,
  ),
  3 => 
  array (
    'id' => 4,
    'nama' => 'Colokan Super',
    'harga' => 8999,
  ),
  4 => 
  array (
    'nama' => 'Saklar Cetek',
    'id' => 5,
    'harga' => 9999,
  ),
  5 => 
  array (
    'nama' => 'Setrika Dingin',
    'id' => 6,
    'harga' => 69999,
  ),
  6 => 
  array (
    'nama' => 'Lampu Redup',
    'id' => 7,
    'harga' => 24999,
  ),
  7 => 
  array (
    'nama' => 'Antena Kabel',
    'id' => 8,
    'harga' => 479999,
  ),
);