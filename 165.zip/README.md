# responsi-pweb
Studi Kasus: TOKO ELEKTRONIK

Bima memiliki toko elektronik seperti hp dan laptop dan lainnya. Agar memudahkan usahanya, ia ingin sebuah website yang bisa menampilkan barang apa saja yang dijual oleh Tokonya. Ia juga ingin websitenya bisa menerima pesanan dari pelanggan yang kemudian setiap pesanan dari pelanggan disimpan kedalam sebuah file .txt yang nantinya bisa dilihat oleh bima apa saja barang yang dipesan oleh pelanggan.

Buatlah website yang bisa memenuhi semua keinginan dalam studi kasus diatas, gunakan semua hal yang sudah dipelajari selama 12 pertemuan praktikum seperti HTML, CSS, JavaScript, dan PHP.

Sandi.23